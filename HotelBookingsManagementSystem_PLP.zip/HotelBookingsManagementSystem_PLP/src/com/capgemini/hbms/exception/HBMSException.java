package com.capgemini.hbms.exception;

public class HBMSException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7092283337963290590L;

	

	public HBMSException() {
		super();
	}



	public HBMSException(String message) {
		super(message);
	}

	
	
}
