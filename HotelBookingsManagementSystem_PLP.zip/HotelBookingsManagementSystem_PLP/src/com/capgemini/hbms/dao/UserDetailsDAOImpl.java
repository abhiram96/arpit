package com.capgemini.hbms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

@Repository
@Transactional
public class UserDetailsDAOImpl implements IUserDetailsDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int RegisterUser(UserDetailsBean userDetails)
			throws HBMSException {
		
		int userId = 0;

		Logger logger = Logger.getRootLogger();
		
		try{
			entityManager.persist(userDetails);
			entityManager.flush();

			userId = userDetails.getUserId();

			logger.info("UserDetailsDAO : User registered !!");
			
		} catch(Exception e){
			logger.info("UserDetailsDAO : User cannot be registered\n" + e.getMessage());
			throw new HBMSException(e.getMessage()); //Throws error	
		}
		
		
	return userId;
		
	}

	@Override
	public List<UserDetailsBean> usersDetail() throws HBMSException {

		List<UserDetailsBean> usersList = new ArrayList<UserDetailsBean>();
		
		try{
			TypedQuery<UserDetailsBean> qry = entityManager.createQuery("from UserDetailsBean",UserDetailsBean.class);
			
			usersList = qry.getResultList();
			
		} catch(Exception e){

			throw new HBMSException(e.getMessage()); //Throws error	
		}
		
		return usersList;
	}

}
