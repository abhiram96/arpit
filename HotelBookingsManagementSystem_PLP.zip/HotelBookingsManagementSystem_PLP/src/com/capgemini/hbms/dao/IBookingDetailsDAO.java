package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IBookingDetailsDAO {
	
	int bookHotelRoom(BookingDetailsBean bookingDetailsBean) throws HBMSException;
	
	BookingDetailsBean getBookingDetail(int bookingId) throws HBMSException;
	
	List<BookingDetailsBean> getBookingDetails(String userId) throws HBMSException;

}
