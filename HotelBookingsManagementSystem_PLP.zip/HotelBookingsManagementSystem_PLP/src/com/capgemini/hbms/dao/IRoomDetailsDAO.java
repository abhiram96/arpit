package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IRoomDetailsDAO {
	
	List<String> getAllRoomIds() throws HBMSException;
	
	double getRoomRate(String roomId) throws HBMSException;
	
	List<RoomDetailsBean> getRoomHotelID() throws HBMSException;

	RoomDetailsBean getRoomDetail(String roomId) throws HBMSException;
	
	List<RoomDetailsBean> viewRooms(String hotelId) throws HBMSException;

}
