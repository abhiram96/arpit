package com.capgemini.hbms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.dao.IUserDetailsDAO;
import com.capgemini.hbms.exception.HBMSException;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	IUserDetailsDAO userDetailsDao;
	
	
	
	
	public IUserDetailsDAO getUserDetailsDao() {
		return userDetailsDao;
	}




	public void setUserDetailsDao(IUserDetailsDAO userDetailsDao) {
		this.userDetailsDao = userDetailsDao;
	}




	@Override
	public int RegisterUser(UserDetailsBean userDetails)
			throws HBMSException {
		
		return userDetailsDao.RegisterUser(userDetails);
	}




	@Override
	public boolean isValidUser(UserDetailsBean userDetails) throws HBMSException {
		
		boolean isValid = false;
		List<UserDetailsBean> usersList = userDetailsDao.usersDetail();
		
		for(UserDetailsBean user : usersList){
			if(user.getUserName().equals(userDetails.getUserName()) && user.getPassword().equals(userDetails.getPassword()) && user.getRole().equals(userDetails.getRole())){
				isValid=true;
				break;	
			}
		}
		return isValid;
	}
}
