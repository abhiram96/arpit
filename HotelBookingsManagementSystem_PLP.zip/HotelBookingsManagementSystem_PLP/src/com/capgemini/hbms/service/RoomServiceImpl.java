package com.capgemini.hbms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.dao.IRoomDetailsDAO;
import com.capgemini.hbms.exception.HBMSException;

@Service
public class RoomServiceImpl implements IRoomService {

	@Autowired
	IRoomDetailsDAO roomDetailsDao;
	
	@Override
	public RoomDetailsBean getRoomDetail(String roomId) throws HBMSException {
		
		return roomDetailsDao.getRoomDetail(roomId);
	}

	@Override
	public boolean isRoomIdValid(String roomId, String hotelId) throws HBMSException {
		
		boolean roomIdFound = false;
		List<RoomDetailsBean> roomIdList;
		try {
			roomIdList = roomDetailsDao.getRoomHotelID();

			for(RoomDetailsBean roomHotelID : roomIdList){
				if(roomHotelID.getRoomId().equals(roomId)&&roomHotelID.getHotelId().equals(hotelId)){
					roomIdFound = true;
					break;
				}
			}

			
		} catch (HBMSException e) {
			System.out.println("Rooms couldnt be found");
			e.printStackTrace();
		}
			
		return roomIdFound;
	}


	@Override
	public List<RoomDetailsBean> viewRooms(String hotelId) throws HBMSException {
		
		return roomDetailsDao.viewRooms(hotelId);  
	}

	@Override
	public double getRoomRate(String roomId) throws HBMSException {
		
		return roomDetailsDao.getRoomRate(roomId);
	}

}
