package com.cg.dao;

import java.util.List;

import com.cg.bean.UserDetailsBean;
import com.cg.exception.TtException;

public interface IUserDetailsDAO {
	
	int RegisterUser(UserDetailsBean userDetails) 
			throws TtException;

	
	List<UserDetailsBean> usersDetail() throws TtException;
	
	
}