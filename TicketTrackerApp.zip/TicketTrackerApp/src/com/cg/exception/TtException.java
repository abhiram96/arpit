package com.cg.exception;

public class TtException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7092283337963290590L;

	

	public TtException() {
		super();
	}



	public TtException(String message) {
		super(message);
	}

	
	
}
