package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.UserDetailsBean;
import com.cg.dao.IUserDetailsDAO;
import com.cg.exception.TtException;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	IUserDetailsDAO userDetailsDao;
	
	
	
	
	public IUserDetailsDAO getUserDetailsDao() {
		return userDetailsDao;
	}




	public void setUserDetailsDao(IUserDetailsDAO userDetailsDao) {
		this.userDetailsDao = userDetailsDao;
	}




	@Override
	public int RegisterUser(UserDetailsBean userDetails)
			throws TtException {
		
		return userDetailsDao.RegisterUser(userDetails);
	}




	@Override
	public boolean isValidUser(UserDetailsBean userDetails) throws TtException {
		
		boolean isValid = false;
		List<UserDetailsBean> usersList = userDetailsDao.usersDetail();
		
		for(UserDetailsBean user : usersList){
			if(user.getUserName().equals(userDetails.getUserName()) && user.getPassword().equals(userDetails.getPassword()) && user.getRole().equals(userDetails.getRole())){
				isValid=true;
				break;	
			}
		}
		return isValid;
	}
}
