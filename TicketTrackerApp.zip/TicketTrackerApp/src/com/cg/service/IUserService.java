package com.cg.service;

import com.cg.bean.UserDetailsBean;
import com.cg.exception.TtException;

public interface IUserService {

	int RegisterUser(UserDetailsBean userDetails) throws TtException;
	
	boolean isValidUser(UserDetailsBean userDetails) throws TtException;

}
